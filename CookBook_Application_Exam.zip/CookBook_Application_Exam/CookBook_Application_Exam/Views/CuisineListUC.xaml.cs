﻿
using System;
using System.Windows.Controls;
using CookBook_Application_Exam.Models;

namespace CookBook_Application_Exam.Views
{
    public partial class CuisineListUC : UserControl
    {
        public CuisineListUC()
        {
            InitializeComponent();
        }

    }
}
